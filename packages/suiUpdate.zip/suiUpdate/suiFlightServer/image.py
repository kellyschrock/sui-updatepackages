#!/usr/bin/env python
"""
image.py
Provides Image
"""

import sqlite3

table_name = 'image'
table_def = 'id INTEGER PRIMARY KEY, time INTEGER, lat INTEGER, lon INTEGER, pitch INTEGER, roll INTEGER, yaw INTEGER, heading INTEGER, alt INTEGER, size INTEGER, path TEXT COLLATE NOCASE'

table_old = 'oldfiles'
def_old = 'id INTEGER PRIMARY KEY, path TEXT COLLATE NOCASE, UNIQUE(path)'

class Image(object):
	""" An Image object has (id, time, lat, lon, pitch, roll, yaw, heading, alt, size, path) """

	def __init__(self, id=None, time=None, lat=None, lon=None, pitch=None, roll=None, yaw=None, heading=None, alt=None, size=None, path=None):
		self.id =   id
		self.time = time
		self.lat =  lat
		self.lon =  lon
		self.pitch= pitch
		self.roll = roll 
		self.yaw = yaw 
		self.heading = heading
		self.alt = alt
		self.size = size
		self.path = path

	def __str__(self):
		hasdata = False
		r = 'Image('
		if self.id is not None:
			r += 'id=' + str(self.id)
			hasdata = True
		if self.time is not None:
			if hasdata:
				r += ', '
			r += 'time=' + str(self.time)
			hasdata = True
		if self.lat is not None:
			if hasdata:
				r += ', '
			r += 'lat=' + str(self.lat)
			hasdata = True
		if self.lon is not None:
			if hasdata:
				r += ', '
			r += 'lon=' + str(self.lon)
			hasdata = True
		if self.pitch is not None:
			if hasdata:
				r += ', '
			r += 'pitch=' + str(self.pitch)
			hasdata = True
		if self.roll is not None:
			if hasdata:
				r += ', '
			r += 'roll=' + str(self.roll)
			hasdata = True
		if self.yaw is not None:
			if hasdata:
				r += ', '
			r += 'yaw=' + str(self.yaw)
			hasdata = True
		if self.heading is not None:
			if hasdata:
				r += ', '
			r += 'heading=' + str(self.heading)
			hasdata = True
		if self.alt is not None:
			if hasdata:
				r += ', '
			r += 'alt=' + str(self.alt)
			hasdata = True
		if self.size is not None:
			if hasdata:
				r += ', '
			r += 'size=' + str(self.size)
			hasdata = True
		if self.path is not None:
			if hasdata:
				r += ', '
			r += 'path="' + str(self.path) + '"'
		r += u')'
		return r

	def insert(self, db):
		""" insert this object into the database """
		rowid = None
		try:
			sql = 'INSERT INTO ' + table_name + '(time, lat, lon, pitch, roll, yaw, heading, alt, size, path) VALUES(?,?,?,?,?,?,?)'
			print sql
			cur = db.cursor()
			cur.execute(sql, (self.time, self.lat, self.lon, self.pitch, self.roll, self.yaw, self.heading, self.alt, self.size, self.path))
			db.commit()
			rowid = self.id = cur.lastrowid
		except sqlite3.Error, e:
			print e
			# raise e
		finally:
			pass
		return rowid

	def update(self, db, changes):
		""" update the database with with these changes to an image """
		try:
			sql = 'UPDATE ' + table_name + ' SET '
			values = []
			need_comma = False
			for k in changes:
				if need_comma:
					sql += ','
				else:
					need_comma = True
				sql += k + '=?'
				values.append(changes[k])
			sql += ' WHERE id=?'
			values.append(self.id)
			print sql, values
			cur = db.cursor()
			cur.execute(sql, values)
			db.commit()
			rowcount = cur.rowcount
			cur.close()
		except sqlite3.Error, e:
			print e
			rowcount = -1
			# raise e
		finally:
			pass
		return rowcount

	def fetch(self, db):
		""" fetch the object associated with self.id from the database """
		fetched = False
		try:
			sql = 'SELECT time, lat, lon, pitch, roll, yaw, heading, alt, size, path FROM ' + table_name + ' WHERE id=?'
			print sql
			cur = db.cursor()
			cur.execute(sql, (self.id,))
			row = cur.fetchone()
			if row is not None:
				self.time = row[0]
				self.lat = row[1]
				self.lon = row[2]
				self.pitch = row[3]
				self.roll = row[4]
				self.yaw = row[5]
				self.heading = row[6]
				self.alt = row[7]
				self.size = row[8]
				self.path = row[9]
				fetched = True
		except sqlite3.Error, e:
			print e
			# raise e
		finally:
			pass
		return fetched

	def delete(self, db):
		""" delete the object associated with self.id from the database """
		try:
			sql = 'DELETE FROM ' + table_name + ' WHERE id=?'
			print sql
			cur = db.cursor()
			cur.execute(sql, (self.id,))
			db.commit()
			rowcount = cur.rowcount
		except sqlite3.Error, e:
			print e
			rowcount = -1
			# raise e
		finally:
			pass
		return rowcount


def make_image(kwargs):
	my_id = None
	my_time = None
	my_lat = None
	my_lon = None
	my_pitch = None
	my_roll = None
	my_yaw = None
	my_heading = None
	my_alt = None
	my_size = None
	my_path = None
	if 'id' in kwargs:
		my_id = kwargs['id']
	if 'time' in kwargs:
		my_time = kwargs['time']
	if 'lat' in kwargs:
		my_lat = kwargs['lat']
	if 'lon' in kwargs:
		my_lon = kwargs['lon']
	if 'pitch' in kwargs:
		my_pitch = kwargs['pitch']
	if 'roll' in kwargs:
		my_roll = kwargs['roll']
	if 'yaw' in kwargs:
		my_yaw = kwargs['yaw']
	if 'heading' in kwargs:
		my_heading = kwargs['heading']
	if 'alt' in kwargs:
		my_alt = kwargs['alt']
	if 'size' in kwargs:
		my_size = kwargs['size']
	if 'path' in kwargs:
		my_path = kwargs['path']
	return Image(my_id, my_time, my_lat, my_lon, my_pitch, my_roll, my_yaw, my_heading, my_alt, my_size, my_path)


def fetchlist(db):
	""" Fetch a list of images from the database """
	imglist = []
	if db is not None:
		sql = 'SELECT t1.id, t1.time, t1.lat, t1.lon, t1.pitch, t1.roll, t1.yaw, t1.heading, t1.alt, t1.size, t1.path FROM ' + table_name + ' t1 WHERE t1.path IS NOT NULL AND path != "" AND NOT EXISTS (SELECT t2.path FROM ' + table_old + ' t2 WHERE t1.path=t2.path) ORDER BY id'
		print sql
		cur = db.cursor()
		for row in cur.execute(sql):
			img = Image(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10])
			imglist.append(img)
	return imglist

